#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xc54e0a01, "module_layout" },
	{ 0x402b8281, "__request_module" },
	{ 0x68d7dd81, "cdev_del" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0x69c77033, "cdev_init" },
	{ 0xfbc74f64, "__copy_from_user" },
	{ 0x13d0adf7, "__kfifo_out" },
	{ 0x67c2fa54, "__copy_to_user" },
	{ 0x2e5810c6, "__aeabi_unwind_cpp_pr1" },
	{ 0x857b93e7, "dvb_dmx_init" },
	{ 0x814541f4, "dvb_unregister_adapter" },
	{ 0x97255bdf, "strlen" },
	{ 0xc068440e, "__kfifo_alloc" },
	{ 0x2666abaf, "dev_set_drvdata" },
	{ 0xa396cbfd, "control_fifo_kernel" },
	{ 0xc8b57c27, "autoremove_wake_function" },
	{ 0xc5ae0182, "malloc_sizes" },
	{ 0x5b6c9014, "dvb_register_frontend" },
	{ 0x91c99831, "device_destroy" },
	{ 0xb59f2c75, "dvb_unregister_frontend" },
	{ 0xe732c68, "userspace_ready" },
	{ 0x62b72b0d, "mutex_unlock" },
	{ 0x7485e15e, "unregister_chrdev_region" },
	{ 0x5fa54f75, "platform_device_register_full" },
	{ 0x34b79527, "dvb_frontend_detach" },
	{ 0x365132bb, "control_readq" },
	{ 0xf6288e02, "__init_waitqueue_head" },
	{ 0x47d2744b, "misc_register" },
	{ 0xed4bdb31, "control_bufsize" },
	{ 0xfa2a45e, "__memzero" },
	{ 0xf5cf326a, "param_ops_short" },
	{ 0xd5d6ab78, "dvb_dmxdev_release" },
	{ 0xdc798d37, "__mutex_init" },
	{ 0x27e1a049, "printk" },
	{ 0x78b253d1, "dvb_dmx_swfilter" },
	{ 0x328a05f1, "strncpy" },
	{ 0x84b183ae, "strncmp" },
	{ 0xe16b893b, "mutex_lock" },
	{ 0xa0d5ada0, "device_create" },
	{ 0xc10d562b, "platform_device_unregister" },
	{ 0x78d59d64, "platform_driver_register" },
	{ 0x87289101, "dvb_dmx_release" },
	{ 0x868784cb, "__symbol_get" },
	{ 0xacc961e0, "inq" },
	{ 0xb38a8029, "cdev_add" },
	{ 0xa82b3131, "hdhomerun_debug_mask" },
	{ 0x8836fca7, "kmem_cache_alloc" },
	{ 0xe4f96f9c, "outq" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x1000e51, "schedule" },
	{ 0x6af8836b, "hdhomerun_control_post_and_wait" },
	{ 0xe65d3789, "dvb_register_adapter" },
	{ 0xdb760f52, "__kfifo_free" },
	{ 0xb9e52429, "__wake_up" },
	{ 0x37a0cba, "kfree" },
	{ 0x75a17bed, "prepare_to_wait" },
	{ 0xf59f197, "param_array_ops" },
	{ 0xba0c8841, "class_destroy" },
	{ 0x8893fa5d, "finish_wait" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0xf23fcb99, "__kfifo_in" },
	{ 0x924bc8ef, "control_fifo_user" },
	{ 0x6e9dd606, "__symbol_put" },
	{ 0x8f678b07, "__stack_chk_guard" },
	{ 0xeb8a3853, "platform_driver_unregister" },
	{ 0x9f8d02a8, "wait_for_write" },
	{ 0x1e093605, "__class_create" },
	{ 0x91a54cdd, "dev_get_drvdata" },
	{ 0x732f369b, "misc_deregister" },
	{ 0x29537c9e, "alloc_chrdev_region" },
	{ 0xbee492b6, "dvb_dmxdev_init" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=dvb-core,dvb_hdhomerun_core";


MODULE_INFO(srcversion, "1F496AAAF6356AB225F26B6");
