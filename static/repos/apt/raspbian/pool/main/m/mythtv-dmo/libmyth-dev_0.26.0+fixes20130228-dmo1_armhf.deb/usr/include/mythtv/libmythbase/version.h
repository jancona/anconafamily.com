#ifndef MYTH_SOURCE_VERSION
#define MYTH_SOURCE_VERSION "v0.26.0"
#define MYTH_SOURCE_PATH    ""
#endif
