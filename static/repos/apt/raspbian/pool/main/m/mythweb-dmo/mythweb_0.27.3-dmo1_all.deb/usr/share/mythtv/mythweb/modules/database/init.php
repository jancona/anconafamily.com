<?php
/**
 *
 * @license     GPL
 *
 * @package     MythWeb
 * @subpackage  Settings
/**/

    $Settings['database'] = array('name'    => t('Database'),
                                  'choices' => array('settings' => t('Database Health'),
                                                    ),
                                  'default' => 'settings',
                                 );
