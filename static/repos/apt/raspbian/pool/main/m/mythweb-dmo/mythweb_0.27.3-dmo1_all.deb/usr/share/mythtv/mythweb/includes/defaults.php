<?php
/**
 * This file is part of MythWeb, a php-based interface for MythTV.
 * See http://www.mythtv.org/ for details.
 *
 * Just a list of defaults for globals
 *
 * @license     GPL
 *
 * @package     MythWeb
 *
/**/

	global $headers;
	$headers = array();
	
	global $Footnotes;
	$Footnotes = array();
