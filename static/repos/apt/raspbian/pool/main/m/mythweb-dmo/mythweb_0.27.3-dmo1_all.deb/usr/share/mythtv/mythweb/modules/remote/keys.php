<?php
/**
 *
 * @license     GPL
 *
 * @package     MythWeb
 *
/**/


// Display the page
    require_once tmpl_dir.'remote.php';
