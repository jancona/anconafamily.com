<?php

interface Cache_Enabled {}
