<?php
/**
 * Welcome page description of the Music module.
 *
 * @license     GPL
 *
 * @package     MythWeb
 *
/**/

// Open with a div and an image
    echo '<div id="info_music" class="hidden">',
         '<img src="', skin_url, '/img/music.png" class="module_icon" alt="">',

// Print a basic overview of what this module does
         t('welcome: music'),

// Next, print a list of possible subsectons
    ####

// Close the div
         "</div>\n";
