<td class="small tv_Unknown" colspan="<?php echo $timeslots_used ?>" valign="top"><?php echo t('NO DATA') ?></td>


