<?php
/*
 * This file is not actually run by mythweb but contains strings that 
 * exist only in the database, so that build_translation.pl does not
 * remove them from the translation files when it can't find them in
 * the rest of the PHP code.
 */

# Recording filter types
t('New episode');
t('Identifiable episode');
t('First showing');
t('Prime time');
t('Commercial free');
t('High definition');
t('This episode');
t('This series');
