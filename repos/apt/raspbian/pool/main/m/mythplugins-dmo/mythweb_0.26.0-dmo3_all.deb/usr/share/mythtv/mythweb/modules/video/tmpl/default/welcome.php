<?php
/**
 * Welcome page description of the Video module.
 *
 * @license     GPL
 *
 * @package     MythWeb
 *
/**/

// Open with a div and an image
    echo '<div id="info_video" class="hidden">',
         '<img src="', skin_url, '/img/video.png" class="module_icon" alt="">',

// Print a basic overview of what this module does
         t('welcome: video'),

// Next, print a list of possible subsectons
    ####

// Close the div
         "</div>\n";
