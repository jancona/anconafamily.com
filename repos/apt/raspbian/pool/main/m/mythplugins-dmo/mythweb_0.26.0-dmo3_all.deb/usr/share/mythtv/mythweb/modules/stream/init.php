<?php
/**
 * Initialization routines for the MythWeb Streaming module
 *
 * @license     GPL
 *
 * @package     MythWeb
 * @subpackage  Music
 *
/**/

    $Settings['stream'] = array('name'    => t('Streaming'),
                                'choices' => array('protocol'  => t('Protocol'),
                                                  ),
                                'default' => 'protocol',
                               );

