#ifndef MYTH_SOURCE_VERSION
#define MYTH_SOURCE_VERSION "9d871a9"
#define MYTH_SOURCE_PATH    "fixes/0.27"
#endif
