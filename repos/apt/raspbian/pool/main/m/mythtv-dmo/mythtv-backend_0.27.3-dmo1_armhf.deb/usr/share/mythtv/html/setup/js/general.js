
setupTabs("generaltabs");

