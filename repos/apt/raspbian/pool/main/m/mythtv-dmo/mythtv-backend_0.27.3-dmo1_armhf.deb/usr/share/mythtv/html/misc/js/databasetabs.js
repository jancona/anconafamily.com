setupTabs("databasetabs");

