
setupTabs("databasetabs");

