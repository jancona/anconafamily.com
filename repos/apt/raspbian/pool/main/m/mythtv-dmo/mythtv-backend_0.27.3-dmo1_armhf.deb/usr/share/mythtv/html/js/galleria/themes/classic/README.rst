======================
Galleria Classic Theme
======================

This is the Galleria Classic Theme that fetches image data from a list of IMG elements and generates thumbnails. If the thumbnail’s total width exceeds the containing width, Galleria automatically adds a carousel (unless disabled). Galleria automatically adjusts it’s width to the containing element’s size.

Check out classic-demo.html for example usage.

Copyright (c) 2010, Aino
Licensed under the MIT license.