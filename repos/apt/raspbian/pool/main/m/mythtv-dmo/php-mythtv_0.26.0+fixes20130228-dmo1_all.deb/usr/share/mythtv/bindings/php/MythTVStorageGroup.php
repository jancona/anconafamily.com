<?php

class MythTVStorageGroup {
    function __construct(&$MythTV, $StorageGroupID = NULL) {
        return FALSE;
    }
}
