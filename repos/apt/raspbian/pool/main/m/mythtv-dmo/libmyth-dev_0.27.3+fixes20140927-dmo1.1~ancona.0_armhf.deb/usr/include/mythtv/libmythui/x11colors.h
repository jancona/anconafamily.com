#ifndef X11COLORS_H_
#define X11COLORS_H_

#include <QColor>
#include <QString>

#include "mythuiexp.h"

MUI_PUBLIC QColor createColor(const QString &color);

#endif

