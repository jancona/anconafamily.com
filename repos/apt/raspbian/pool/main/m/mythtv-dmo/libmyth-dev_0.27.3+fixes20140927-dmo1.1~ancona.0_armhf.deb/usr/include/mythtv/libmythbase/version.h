#ifndef MYTH_SOURCE_VERSION
#define MYTH_SOURCE_VERSION "v0.27.3"
#define MYTH_SOURCE_PATH    ""
#endif
