<?php
/*
 *  Due to how strings are translated, there isn't always a hardcoded string
 *  for the build_translations.pl script to pick up. This file provides a
 *  way to have them picked up.
 */
    t('Cache_Null');
    t('Cache_APC');
    t('Cache_SHM');
    t('Cache_Memcache');
    t('Cache_Memcached');
    t('You must be running at least php 5.3 to use this program.');
    t('You are missing a php extension for mysql interaction. Please install php-mysqli or similar');
    t('generic_date');
    t('generic_time');
    
