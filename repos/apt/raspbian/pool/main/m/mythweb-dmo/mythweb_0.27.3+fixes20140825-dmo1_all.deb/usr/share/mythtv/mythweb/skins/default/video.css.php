<?php header("Content-type: text/css"); ?>
    .video {
        position:           relative;
        padding:            1em;
        float:              left;
        background-color:   #003366;
        margin-top:         1em;
        margin-left:        1em;
        width:              <?php echo (_or(setting('web_video_thumbnail_width',  hostname),  96)+106); ?>px;
        height:             <?php echo (_or(setting('web_video_thumbnail_height', hostname), 140)+28 ); ?>px;
        border:             1px solid black;
    }

    .video .title {
        font-weight:        bold;
        margin-bottom:      .5em;
        height:             2.5em;
        overflow:           hidden;
    }

    .video img {
        float:              left;
        padding-right:      1em;
    }

    .video .command {
        position:           absolute;
        bottom:             1em;
        right:              1em;
    }

    #path {
        position:           relative;
        padding:            1em;
        float:              left;
        background-color:   #102923;
        margin-top:         1em;
        margin-left:        1em;
        border:             1px solid black;
        min-width:          <?php echo (_or(setting('web_video_thumbnail_width',  hostname),  96)+106); ?>px;
        min-height:         <?php echo (_or(setting('web_video_thumbnail_height', hostname), 140)+28 ); ?>px;
    }

    #path .active {
        color:              yellow;
    }

    #window {
        position:           fixed;
        left:               35%;
        right:              35%;
        width:              30%;
        top:                35%;
        background-color:   green;
        padding-top:        1em;
        z-index:            10;
        border:             2px solid gray;
    }

    #window_content a {
        padding-right:      1em;
        padding-left:       1em;
    }

    #window iframe {
        width:              100%;
        border:             0px;
        height:             250px;
    }

    #window_title {
        position:           absolute;
        top:                1px;
        left:               1em;
        font-weight:        bold;
    }

    .popup {
        width:              30%;
        font-size:          9pt;
    }

    .popup dt {
        clear:              left;
        float:              left;
        padding-top:        3px;
        white-space:        nowrap;
        width:              6em;
        font-weight:        bold;
        text-align:         right;
    }

    .popup  dd {
        margin-left:        6.5em;
        padding-top:        3px;
    }
