<?php
/**
 * Initialization routines for the MythWeb Video Coverart module
 *
 * @license     GPL
 *
 * @package     MythWeb
 * @subpackage  Video Coverart
 *
/**/
?>
