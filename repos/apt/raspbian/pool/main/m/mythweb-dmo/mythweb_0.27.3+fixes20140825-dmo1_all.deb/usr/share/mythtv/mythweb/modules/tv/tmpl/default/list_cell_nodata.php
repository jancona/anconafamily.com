<td class="small tv_Unknown" colspan="<?php echo _or($timeslots_used,1); ?>" valign="top"><?php echo t('NO DATA') ?></td>
